Jalankan program dengan menuliskan di termin
python main.py <nama_file_input>.txt